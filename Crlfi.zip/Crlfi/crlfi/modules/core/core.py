import asyncio
import aiohttp
from aiohttp.client_exceptions import ClientResponseError, ClientPayloadError, InvalidURL
import aiofiles
import os  
from colorama import Fore,Style
import requests
from bs4 import BeautifulSoup
import time as t
import warnings
import random
from alive_progress import alive_bar
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
from aiohttp import client_exceptions
requests.packages.urllib3.disable_warnings()
import uvloop
from .notify.notify import notify
from fake_useragent import UserAgent

red =  Fore.RED
green = Fore.GREEN
magenta = Fore.MAGENTA
cyan = Fore.CYAN
mixed = Fore.RED + Fore.BLUE
blue = Fore.BLUE
yellow = Fore.YELLOW
white = Fore.WHITE
lm = Fore.LIGHTMAGENTA_EX
reset = Style.RESET_ALL
bold = Style.BRIGHT
colors = [ white, cyan, blue]
random_color = random.choice(colors)

async def save(url, args):
    try:
            if args.output:
                if os.path.isfile(args.output):
                    filename = args.output
                elif os.path.isdir(args.output):
                    filename = os.path.join(args.output, f"Crlfi-outputs.txt")
                else:
                    filename = args.output
            else:
                    filename = "Crlfi-outputs.txt"
                    
            async with aiofiles.open(filename, "a") as w:
                    await w.write(url + '\n')

    except KeyboardInterrupt as e:        
        SystemExit
        
    except asyncio.CancelledError as e:
        SystemExit
        
    except Exception as e:
        pass
    
    
async def crlfi(url, args, sem, bar, session, configpath, username):
    try:
            warnings.filterwarnings("ignore", category=ResourceWarning)
            
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
            
            headers={}
            
            timeout = args.timeout
            
            redirect = True if args.allow_redirect else False
            
            if args.header:
                for header in args.header:
                    name, value = header.split(':', 1)
                    headers[name.strip()] = value.strip()
            
            headers["User-Agent"] = UserAgent().random
            
            async with session.request(args.method.upper(),url, headers=headers,ssl=False, proxy=args.proxy, timeout=timeout, allow_redirects=redirect, max_redirects=args.max_redirection) as response:
                await asyncio.sleep(0.00001)
                responsed = await response.content.read()
                for header, value in response.headers.items():
                    if value == "whoami=ibro":
                        if args.no_color:
                            print(f"[Vuln]: {url} [{response.status}] [{header}:{value}] [{response.url}]")
                        else:
                            print(f"[{bold}{green}Vuln{reset}]: {bold}{white}{url}{reset} [{bold}{green}{response.status}{reset}] [{bold}{yellow}{header}{reset}:{bold}{yellow}{value}{reset}] [{bold}{magenta}{response.url}{reset}]")
                            
                        output = f"{url} [{response.status}] [{header}:{value}] [{response.url}]"
                        await save(output, args)
                        if args.notify:
                            await notify(url, configpath, username, args)
            
    except KeyboardInterrupt as e:
        SystemExit
    
    except aiohttp.ClientConnectorError as e:
        pass
        
    except aiohttp.ClientConnectionError as e:
        
        if args.verbose:
            print(f"[{bold}{red}INFO{reset}]: {bold}{white}Client Connection Exceeds for: {url}{reset}")
            
    except asyncio.TimeoutError as e:
         if args.verbose:
            print(f"[{bold}{red}INFO{reset}]: {bold}{white}Client Timeout Exceeds for: {url}{reset}")
            
    except asyncio.CancelledError as e:
        SystemExit
        
    except InvalidURL as e:
        pass
    except UnicodeError as e:
        pass

    except (ClientResponseError, ClientPayloadError) as e:
        pass
        
    except Exception as e:
        if args.verbose:
            print(f"Exception at request: {e}, {type(e)}")
    
    finally:
        bar()
        sem.release()
        

async def start(urls,args, session,sem, bar, username, configpath):
    try:
        tasks = []
        for url in urls:
            await sem.acquire()
            task = asyncio.ensure_future(crlfi(url, args, sem, bar, session, configpath, username))
            tasks.append(task)
        await asyncio.gather(*tasks, return_exceptions=False)
    except KeyboardInterrupt as e:
        SystemExit
    
    except asyncio.CancelledError as e:
        SystemExit
        
    except Exception as e:
        if args.verbose:
            print(f"Exception at initiate: {e}, {type(e)}")
            
async def core(urls, args, username, configpath):
    try:
        urls = list(set(urls))
        
        customloops = uvloop.new_event_loop()
        asyncio.set_event_loop(loop=customloops)
        loops = asyncio.get_event_loop()
        sem = asyncio.BoundedSemaphore(args.concurrency)
        async with aiohttp.ClientSession(loop=loops) as session:
            with alive_bar(title=f"Crlfi", total=len(urls), enrich_print=False) as bar:
                loops.run_until_complete(await start(urls, args, session, sem, bar, username, configpath))
        
    except KeyboardInterrupt as e:
        
        SystemExit
        
    except asyncio.CancelledError as e:  
        SystemExit
    except RuntimeError as e:
        SystemExit
    except Exception as e:
        if args.verbose:
            print(f"Exception At concurrents: {e}, {type(e)}")