import os
import sys
import random
from colorama import Fore, Style
import time
import asyncio
import aiohttp
import aiofiles

red =  Fore.RED
green = Fore.GREEN
magenta = Fore.MAGENTA
cyan = Fore.CYAN
mixed = Fore.RED + Fore.BLUE
blue = Fore.BLUE
yellow = Fore.YELLOW
white = Fore.WHITE
reset = Style.RESET_ALL
bold = Style.BRIGHT
colors = [ green, cyan, blue]
random_color = random.choice(colors)

try:
    from .banner.banner import banner
    from .cli.cli import cli
    from .core.core import core
    from .config.config import config, get_username
    from .help.help import help
except ImportError as e:
    print(f"[{bold}{red}INFO{reset}]: {bold}{white}Import Error occured in  Crlfi Module imports due to: {e}{reset}", file=sys.stderr)
    exit()
    
    
args = cli()
configpath = config()
banners = banner()
username = get_username()
    
url_list = []
all = [] 
final= []



async def handler():
    print(banners)
    if args.help:
        help()
        quit()
    
    if not args.payloads:
        if args.no_color:
            print(f"[WRN]: Please provide a file containing crlf payloads")
        else:
            print(f"[{bold}{red}WRN{reset}]: {bold}{white}Please provide a file containing crlf payloads{reset}")
    print(f"[{bold}{blue}INF{reset}]: {bold}{white}Loading notify config from {configpath}{reset}")
    if args.urls:
        
        try:
            
            async with aiofiles.open(args.urls, "r") as urls:
                
                async for url in urls:
                    url = url.strip()
                    path = "" if url.endswith("/") else "/"
                        
                    url = f"{url}{path}"
                        
                    if url.startswith("https://") or url.startswith("http://") :
                                
                        url_list.append(url)
                            
                    elif not  url.startswith("https://") or url.startswith("http://"):
                        new_url = f"https://{url}"
                        url_list.append(new_url)
                        new_http = f"http://{url}"
                        url_list.append(new_http)
                    
        except FileNotFoundError as e:
            if args.no_color:
                print(f"[WRN]: Please check {args.urls} exists")
            else:
                print(f"[{bold}{red}WRN{reset}]: {bold}{white}Please check {args.urls} exists{reset}")
            
            quit()
        except Exception as e:
            pass
        
        
        try:
            async with aiofiles.open(args.payloads, "r") as payloads:
                async for payload in payloads:
                    payload = payload.strip()
                    final.append(payload)
        except FileNotFoundError as e:
            if args.no_color:
                print(f"[WRN]: Please check {args.payloads} exists")
            else:
                print(f"[{bold}{red}WRN{reset}]: {bold}{white}Please check {args.payloads} exists{reset}")
            
            quit()
        except Exception as e:
            pass
        for payload in final:
           for url in url_list:
               all.append(url+payload)
               
        await core(all, args, username, configpath)
    
    if not args.urls:
        for url in sys.stdin:
            url = url.strip()
            path = "" if url.endswith("/") else "/"
                        
            url = f"{url}{path}"
                        
            if url.startswith("https://") or url.startswith("http://") :
                                
                url_list.append(url)
                            
            elif not  url.startswith("https://") or url.startswith("http://"):
                new_url = f"https://{url}"
                url_list.append(new_url)
                new_http = f"http://{url}"
                url_list.append(new_http)
                
        try:
            async with aiofiles.open(args.payloads, "r") as payloads:
                    async for payload in payloads:
                        payload = payload.strip()
                        final.append(payload)
        except FileNotFoundError as e:
            if args.no_color:
                print(f"[WRN]: Please check {args.payloads} exists")
            else:
                print(f"[{bold}{red}WRN{reset}]: {bold}{white}Please check {args.payloads} exists{reset}")
            
            quit()
        except Exception as e:
            pass
        
        for url in url_list:
           for payload in final:
               all.append(url+payload)
        await core(all, args, username, configpath)
        
def MAIN():
    asyncio.run(handler())