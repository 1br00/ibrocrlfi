from colorama import Fore,Style
red =  Fore.RED
green = Fore.GREEN
magenta = Fore.MAGENTA
cyan = Fore.CYAN
mixed = Fore.RED + Fore.BLUE
blue = Fore.BLUE
yellow = Fore.YELLOW
white = Fore.WHITE
reset = Style.RESET_ALL
bold = Style.BRIGHT
colors = [ green, cyan, blue]

def help():
    print(f"""
          
{bold}{white}Crlfi - A Crlf Injection detection tool for Penetration Tester and Security Researchers

{bold}[{bold}{blue}Description{reset}{bold}{white}]{reset} :

    {bold}{white}Crlf injection is a highly concurrent tool to detect the CRLF vulnerability.{reset}

{bold}[{bold}{blue}Options{reset}{bold}{white}]{reset}:{reset}{bold}{white}

    {bold}[{bold}{blue}INPUT{reset}{bold}{white}]{reset}:{reset}{bold}{white}

        -urls,    --urls               specify the filename containing a list of urls
        -pl,      --payloads           specify a filename contaning a list crlf payloads to detect                                      
        stdin/stdout                   supports both stdin/stdout and enable -nc to pipe the output
                                      
    {bold}[{bold}{blue}PROBES-CONFIG{reset}{bold}{white}]{reset}:{reset}{bold}{white}

        -px,   --proxy                 specify a proxy to send the requests through your proxy or BurpSuite (ex: http://127.0.0.1:8080)
        -ar,   --allow-redirect        enabling these flag will make Subprober to follow the redirection and ger results
        -X  ,  --method                request methods to probe and get response
        -H  ,  --header                add a custom headers for request and -H can be used multiple times to pass multiple header values (ex: -H application/json -H X-Forwarded-Host: 127.0.0.1)
        -mxr,  --max-redirection       set a max value to follow redirection (default: 10)
        -to,   --timeout               set a custom timeout value for sending requests.
        -c,    --concurrency           set the concurrency level for subprober (default 100)
                                      
    {bold}[{bold}{blue}OUTPUT{reset}{bold}{white}]{reset}:{reset}{bold}{white}
    
        -o,    --output                define the output filename to store the results

    {bold}[{bold}{blue}DEBUG{reset}{bold}{white}]{reset}:{reset}{bold}{white}
    
        -h,    --help                  show this help message for you and exit!
        -v,    --verbose               enable verbose mode to display error results on the console.
        -nc,   --no-color              enabling the --no-color will display the output without any CLI colors
        -nt,   --notify                send notification when finding vulnerable target{reset}""")
    quit()