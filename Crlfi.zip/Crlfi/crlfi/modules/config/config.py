import appdirs
from colorama import Fore, Back, Style
import os
import sys

white = Fore.WHITE
blue = Fore.BLUE
red = Fore.RED
bold = Style.BRIGHT
reset = Style.RESET_ALL

yamls = """slack: []
"""

def get_username():
    
    try:
        username = os.getlogin()
    except OSError:
        username = os.getenv('USER') or os.getenv('LOGNAME') or os.getenv('USERNAME') or 'Unknown User'
    except Exception as e:
        username = "Unknown User"
    return username


def config(): 
    try:
        
        get_config = appdirs.user_config_dir()
        crlfi_dir = f"{get_config}/Crlfi"
        filename = "provider-config.yaml"
        config_path = f"{crlfi_dir}/{filename}"
        
        if os.path.exists(crlfi_dir):
            
            if os.path.exists(config_path):
                pass
            else:
                with open(config_path, "w") as w:
                    w.write(yamls)
        else:
            os.makedirs(crlfi_dir)
            with open(config_path, "w") as w:
                w.write(yamls)
        return config_path
        
    except Exception as e:
        pass