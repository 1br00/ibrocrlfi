from .modules.handler import MAIN

def main():
    MAIN()
    
if __name__ == "__main__":
    main()