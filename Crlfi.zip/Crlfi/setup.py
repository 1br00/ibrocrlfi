from setuptools import setup, find_packages


setup(
    name='crlfi',
    version='1.0.0',
    author='D. Sanjai Kumar',
    author_email='bughunterz0047@gmail.com',
    description='Crlfi -  A Crlf injection vulnerability detection tool',
    packages=find_packages(),
    install_requires=[
        'aiofiles>=23.2.1',
        'aiohttp>=3.9.4',
        'appdirs>=1.4.4',
        'art>=6.1',
        'fake_useragent>=1.5.0',
        'beautifulsoup4>=4.11.1',
        'PyYAML>=6.0.1',
        'Requests>=2.31.0',
        'rich>=13.7.1',
        'urllib3>=1.26.18',
        'uvloop>=0.19.0'
    ],
    entry_points={
        'console_scripts': [
            'crlfi = crlfi.crlfi:main'
        ]
    },
)